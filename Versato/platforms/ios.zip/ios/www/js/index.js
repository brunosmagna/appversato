/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },
    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
        $.support.cors = true;
        $.mobile.allowCrossDomainPages = true;
    
    },

    // Update DOM on a Received Event
    receivedEvent: function(id) {
    
    }

};

app.initialize();

$(document).on("mobileinit", function(){
    $.mobile.page.prototype.options.domCache = false;
    $.mobile.pageContainer = $('#container');
    $.mobile.defaultPageTransition = 'slide';
    var db = window.openDatabase("versatto", "1.0", "data", 1000000);
});

$.mobile.page.prototype.options.domCache = false;
$.mobile.pageContainer = $('#container');
var db = window.openDatabase("versatto", "1.0", "data", 1000000);



_site           =   "https://sistema.versatozapatos.com/";
_users          =   "/api/users";
_delivery       =   window.localStorage.getItem("deliverycenters");
_firstrun       =   window.localStorage.getItem("firstrun");
_userPicture    =   window.localStorage.getItem('userPicture');
_lastSync       =   window.localStorage.getItem('lastSync');
_everSynced     =   window.localStorage.getItem('everSynced');
_deviceType     =   (navigator.userAgent.match(/iPad/i))  == "iPad" ? "iPad" : (navigator.userAgent.match(/Chrome/i))  == "Chrome" ? "Chrome" : "null";
brands          =   { selecionada : '', row : '', title : '', id : '' };
tempToken       =   { data : '' };



function ConnectionStatus() {
    var connectionStatus = false;
    connectionStatus = navigator.onLine ? 'online' : 'offline';
    if (connectionStatus == "online") { $('#connectionStatus').html('<b style="color:lightgreen">Online</b>'); } else { $('#connectionStatus').html('<b style="color:red">Offline</b>'); }
    return connectionStatus;
}


function scan(){
    cordova.plugins.barcodeScanner.scan(
        function (result) {
            if(!result.cancelled)
            {
                if(result.format == "QR_CODE")
                {   
                    tempToken.data = result.text;
                    $('#inputToken').text(result.text);
                    window.localStorage.setItem("token", result.text);
                    syncUser();
                }
            }
        },
        function (error) {
            alert(error);
        }
   );
}


$(document).on("pagebeforecreate", "#first-run", function(){

    var start = _firstrun ? $.mobile.changePage( "#brands", { transition: "fadeIn", reverse: false,  allowSamePageTransition : true, changeHash: true }) : console.log('first');
    
    $(document).on("click",".qrCode", scan);

    $(document).on('click', '.loginBtn', function(event) {
        if ($('#inputToken').val().length === 0) { 
            navigator.notification.alert(
                'Preencha o Campo de Segurança.',  // message
                console.log('tudo bem'),         // callback  
                'Token de Segurança',            // title
                'Entendido'                  // buttonName
            );
        } else {
            
            window.localStorage.setItem("token", $('#inputToken').val());

            tempToken.data = $('#inputToken').val();

            $.ajax({
                url: _site+"api/user",
                headers: {"Authorization": "Bearer " + $('#inputToken').val()},
                method: "GET",
                beforeSend: function() { $.mobile.loading('show', {text: "Carregando dados Usuário", textVisible: "Sincronizando Usuário"}); }, 
                afterSend: function() { $.mobile.loading('hide'); }, 
                success:function (data) {
                    // Seleciona o primeiro usuário da lista pq eu nao sou palhaço
                    // Seta algumas configurações básicas
                    window.localStorage.setItem("username", data.name +' '+ data.lastname);
                    window.localStorage.setItem("userpicture", data.photo);
                    window.localStorage.setItem("user_id", data.id);
                    window.localStorage.setItem("rep_id",data.representative.id);
                    window.localStorage.setItem("rep_code",data.representative.code);
                    window.localStorage.setItem("firstrun","true");
                    window.localStorage.setItem('everSynced',"false");
                    window.localStorage.setItem("firstSync","true");
                    window.localStorage.setItem("token", tempToken.data);
                    ConnectionStatus(); 
                    syncDataUser();
                    
                },
                error: function(response) {
                    navigator.notification.alert(
                        'Não foi possível sincronizar. Verifique seu Token de Segurança e tente novamente.',  // message
                        console.log('tudo bem'),         // callback  
                        'Token de Segurança',            // title
                        'Entendido'                  // buttonName
                    );
                     
                }
            });
        }
        
    });
});


function syncUser(){
    $.ajax({
        url: _site+"api/user",
        headers: {"Authorization": "Bearer " + tempToken.data},
        beforeSend: function() { $.mobile.loading('show', {text: "Carregando dados Usuário", textVisible: "Sincronizando Usuário"}); }, 
        afterSend: function() { $.mobile.loading('hide'); }, 
        success:function (data) {
            // Seleciona o primeiro usuário da lista pq eu nao sou palhaço
            // Seta algumas configurações básicas
            window.localStorage.setItem("username", data.name +' '+ data.lastname);
            window.localStorage.setItem("userpicture", data.photo);
            window.localStorage.setItem("user_id", data.id);
            window.localStorage.setItem("rep_id",data.representative.id);
            window.localStorage.setItem("rep_code",data.representative.code);
            window.localStorage.setItem("firstrun","true");
            window.localStorage.setItem('everSynced',"false");
            window.localStorage.setItem("firstSync","true");
            window.localStorage.setItem("token", tempToken.data);
            ConnectionStatus(); 
            syncDataUser();
        },
        error: function(response) {
            $.mobile.loading('hide');
            navigator.notification.alert(
                'Não foi possível sincronizar. Verifique seu Token de Segurança e tente novamente.',  // message
                console.log('tudo bem'),         // callback  
                'Token de Segurança',            // title
                'Entendido'                  // buttonName
            );
        }
    })
}

function syncDataUser(){

    var token = window.localStorage.getItem("token");

    $.ajax({
        url:  _site+"api/customers/selectlist",
        headers: {"Authorization": "Bearer " + tempToken.data},
        method: "GET",
        beforeSend: function() { $.mobile.loading('show', {text: "Carregando Itens"}); }, 
        afterSend: function() { $.mobile.loading('hide'); }, 
        success:function (data) {

            console.log('[CUSTOMERS] Carregados com sucesso');
            
            window.localStorage.setItem("customers", JSON.stringify(data));
        },
        error: function(model, response) {
            alert('Customer: ocorreu um erro ao carregar Customers via Ajax');
        }
    });    

    $.ajax({
        url:  _site+"api/brands",
        headers: {"Authorization": "Bearer " + tempToken.data},
        method: "GET",
        beforeSend: function() { $.mobile.loading('show', {text: "Carregando Itens"}); }, 
        success:function (data) {
            
            console.log('[BRANDS] Carregadas com sucesso');

            window.localStorage.setItem("brands", JSON.stringify(data));

            var datinha = JSON.stringify(data);
            
            var i;

            // for (; i < datinha.length; i = i + 1) {
            //     ImgCache.cacheFile(datinha[i].image);
            // }

            $.mobile.changePage( "#brands", {
                transition: "fade",
                reverse: false,
                changeHash: true,
                 allowSamePageTransition : true
            });

        },
        error: function(model, response) {
            alert('Customer: ocorreu um erro ao carregar Brands via Ajax');
        }
    });    
}

$(document).on("pageshow","#brands", function(event){

    var brands    =     window.localStorage.getItem("brands");
    var username  =     window.localStorage.getItem("username");
    var userphoto =     window.localStorage.getItem("userpicture");
    var marcas    =     JSON.parse(brands);

    $('.username-label').text(username);

    $('.userAvatar img').attr('src',userphoto);

    $('#brandsList').empty();

    $.mobile.loading('show');
    
    i = 0;
    
    for (; i < marcas.length; i = i + 1) {

        $('#brandsList').append(
            '<li>'+
            '<a href="#"  data-brandId='+marcas[i].id+' data-brandRow='+i+' data-brandTitle="'+decodeURI(marcas[i].name)+'">' +
            '<img id="#imgid'+i+'" class="cached-img" style="width:100%" data-image="'+marcas[i].image+'" src='+marcas[i].image+'></img>' +
            '</a>' +
            '</li>'
        );
    }

        

    $('#brandsList').listview('refresh');

    // var obj = $('#brandsList li');

    //     $.each( obj, function( key, value ) {
    //       var target = $(this).find('img');

    //       ImgCache.cacheFile(target.attr('src'), function () {
    //           ImgCache.useCachedFile(target, function () {
    //             // alert('now using local copy');
    //           }, function(){
    //             // alert('could not load from cache');
    //           })
    //         });
    //     });
        
    $.mobile.loading('hide');
});

$(document).on( "click", "#brandsList a", function() {
    brands.selecionada = $(this).attr('data-brandId');
    brands.row = $(this).attr('data-brandRow');
    brands.title = $(this).attr('data-brandTitle');
    brands.id = $(this).attr('data-brandId');
    $.mobile.changePage( "#catalogo", {
        transition: "slide",
        reverse: false,
        changeHash: true,
        allowSamePageTransition : true
    });
 });

// $(document).on("pageinit","#catalogo", function(event){
//     ConnectionStatus();
//     // $('#sapatosList').css('opacity','1');
//     $('#pageTitle').text(brands.title);
//       // Check se a é a primeira vez que o usuário loga
//     var _everSynced     = window.localStorage.getItem('everSynced');

//     if (_everSynced == "false") {
//         $('#naoAtualizado').css('display','block');
//     } else {
//         $('#naoAtualizado').css('display','none');
//         // renderList();
//     }
//     // var sincronizado = _everSynced ? alert('true') : alert('false');
// }); 

$(document).on('pagecreate','#catalogo', function(event){

    $('#pageTitle').text(brands.title);

    var _everSynced     = window.localStorage.getItem('everSynced');

    if (_everSynced == "false") {
        $('#naoAtualizado').css('display','block');
    } else {
        $('#naoAtualizado').css('display','none');
        // renderList();
    }

    $('.atualizaSistema').on('click', function(){
        if (ConnectionStatus() == "online") {
            if (localStorage.getItem("itensOffline") === null) {
                catalogo.sync(renderList);
            } else {
                var itensArmazenados = JSON.parse(window.localStorage.getItem("itensOffline"));
                navigator.notification.alert(
                    'Você possui '+itensArmazenados.length+' itens para enviar. Você deve enviá-los antes de atualizar seu catálogo.',  // message
                    enviaPedidoOffline(),         // callback
                    'Pedidos Armazenados',            // title
                    'Entendido'                  // buttonName
                );
                function enviaPedidoOffline() {
                    var token = window.localStorage.getItem("token");
                    var itensArmazenados = JSON.parse(window.localStorage.getItem("itensOffline"));
                    $.each(itensArmazenados, function(i, item) {
                        $.ajax({
                          url: _site+"api/orders/",
                          headers: {"Authorization": "Bearer " + token},
                          method: "POST",
                          data: item,
                          success: function(data, status) {
                            console.log("Order response" + JSON.stringify(data));
                            if (_deviceType == "Chrome") {
                                alert('Order enviada com sucesso');
                                localStorage.removeItem('itensOffline');
                            } else {
                                navigator.notification.alert(
                                    'Pedido #'+data.id+' enviado com sucesso.',  // message
                                    localStorage.removeItem('itensOffline'),         // callback
                                    'Pedido #'+data.id,            // title
                                    'Entendido'                  // buttonName
                                );
                                $.mobile.loading('hide'); 
                            }
                          },
                          error: function(data, status){ alert(JSON.stringify(data) +'===== STATUS ====='+ JSON.stringify(status))},
                          beforeSend: function() { $.mobile.loading('show', {text: "Carregando Itens"}) },
                          afterSend: function() { $.mobile.loading('hide'); } 
                        });
                    });
                    $.mobile.loading('hide') 
                }
            }

        } else { 
            alert('Você precisa estar conectado à internet para fazer atualizações no catálogo.');
        }
    });
 })



// Catalogo
window.catalogo =  {

    syncURL: "https://sistema.versatozapatos.com/api/products/sync/",

    initialize: function(callback) {
        var self = this;
        this.db = window.openDatabase("versato", "1.0", "Versato Database Files", 200000);
        
        this.db.transaction(
            function(tx) {
                tx.executeSql("SELECT name FROM sqlite_master WHERE type='table' AND name='sapato'", this.txErrorHandler,
                    function(tx, results) {
                        if (results.rows.length == 1) {
                            console.log('Utilizando a tabela Sapatos já existente no local');
                        }
                        else
                        {
                            console.log('A tabela Sapatos não existe no local. Criando');
                            self.createTable(callback);
                        }
                    });
            }
        )

    },
        
    createTable: function(callback) {
        this.db.transaction(
            function(tx) {
                var sql =
                    "CREATE TABLE IF NOT EXISTS sapato ( " +
                    "id INTEGER PRIMARY KEY, " +
                    "code VARCHAR(1000), " +
                    "brand_id INTEGER, " +
                    "line_id INTEGER, " +
                    "brand_name VARCHAR(50), " +
                    "price VARCHAR(50), " +
                    "costo VARCHAR(50)," +
                    "reference_id INTEGER, " +
                    "material_id INTEGER, " +
                    "color_id INTEGER, " +
                    "photo VARCHAR(50), " +
                    "linha_desc VARCHAR(50), " +
                    "linha_code INTEGER, " +
                    "referencia_id INTEGER, " +
                    "color_code VARCHAR(50), " +
                    "color_desc VARCHAR(50), " +
                    "material_desc VARCHAR(50), " +
                    "lastModified VARCHAR(50)," +
                    "linha INTEGER, " +
                    "grid VARCHAR(300));"
                tx.executeSql(sql);
            },
            this.txErrorHandler,
            function() {
                console.log('Tabela criada com sucesso');
                callback();
            }
        );
    },

    findAll: function(callback) {
        this.db.transaction(
            function(tx) {
                var sql = "SELECT * FROM SAPATO WHERE brand_id = '"+brands.selecionada+"'";
                console.log('Local SQLite database: "SELECT * FROM SAPATO"');
                tx.executeSql(sql, this.txErrorHandler,
                    function(tx, results) {
                        var len = results.rows.length,
                            sapatos = [],
                            i = 0;
                        for (; i < len; i = i + 1) {
                            sapatos[i] = results.rows.item(i);
                        }
                        console.log(len + ' sapatos encontrados');
                        callback(sapatos);
                    }
                );
            }
        );
        catalogo.syncFilters();
    },

    getLastSync: function(callback) {
        this.db.transaction(
            function(tx) {
                var sql = "SELECT MAX(lastModified) as lastSync FROM sapato";
                tx.executeSql(sql, this.txErrorHandler,
                    function(tx, results) {
                        var lastSync = results.rows.item(0).lastSync;
                        console.log('A ultima atualização foi em ' + lastSync);
                        callback(lastSync);
                    }
                );
            }
        );
    },

    sync: function(callback) {

        var self = this;
        console.log('Iniciando sincronização...');
        this.getLastSync(function(lastSync){
            self.getChanges(self.syncURL, lastSync,
                function (changes) {
                    if (changes.length > 0) {
                        
                        self.applyChanges(changes, callback);

                    } else {
                        navigator.notification.alert(
                            'No momento não existem novas atualizações',  
                            $.mobile.loading('hide'),       
                            'Atualização de Catálogo',          
                            'Entendido'               
                        );
                    }
                }
            );
        });

    },

     dropTable: function(callback) {
        this.db.transaction(
            function(tx) {
                tx.executeSql('DROP TABLE IF EXISTS sapato');
            },
            this.txErrorHandler,
            function() {
                console.log('Dropou a tabela SAPATO');
                callback();
            }
        );
    },

    getChanges: function(syncURL, modifiedSince, callback) {

        var firstSync = window.localStorage.getItem("firstSync");
            var token = window.localStorage.getItem("token");


        // Adiciona 1 segundo no horário para que não pegue novamente o último resultado sincronizado
        function increment_last(v) {
            return v.replace(/[0-9]+(?!.*[0-9])/, function(match) {
                return parseInt(match, 10)+1;
            });
        }

        // Se for o primeiro sync ele pega uma data qualquer para que baixe todos os dados do servidor

        if (firstSync == "true") {
            $.ajax({
                url: syncURL+'0000-00-00',
                beforeSend: function() { $.mobile.loading('show', {text: "Sincronizando Catálogo", textVisible: "Sincronizando Catálogo"});  }, 
                headers: {"Authorization": "Bearer " + token},
                dataType:"json",
                success:function (data) {
                    callback(data);
                    function onConfirmAtualizar(buttonIndex) {
                        if (buttonIndex == '1') {
                            window.localStorage.setItem("firstSync","false");
                            callback(data);
                        } else {
                            $.mobile.loading('hide');
                        }
                    }
                    // navigator.notification.confirm(
                    //     'Foram encontrados '+data.length+' itens na base de dados. Você deseja atualizar agora?',  // message
                    //     onConfirmAtualizar,         // callback
                    //     'Atualização de Catálogo',            // title
                    //     ['Sim','Depois']     // buttonLabels
                    // );
                },
                error: function(model, response) {
                    alert(response.responseText);
                }
            });

        } else {
            $.ajax({
                url: syncURL+increment_last(decodeURI(modifiedSince)),
                beforeSend: function() { $.mobile.loading('show', {text: "Verificando Atualizações", textVisible: "Verificando Atualizações"}); }, 
                headers: {"Authorization": "Bearer " + token},
                dataType:"json",
                crossDomain: true,
                success:function (data) {
                    callback(data);
                    // if (data.length == 0) {
                    //     callback(data);
                    // } else {
                    //     navigator.notification.confirm(
                    //         'Foram encontradas '+data.length+' mudanças na base de dados. Você deseja atualizar?',  // message
                    //         callback(data),        // callback
                    //         'Atualização de Catálogo',            // title
                    //         ['Sim','Depois']     // buttonLabels
                    //     );  
                    // }
                },
                error: function(model, response) {
                    alert(response.responseText);
                }
            });
        }
    },

    applyChanges: function(sapatos, callback) {
        this.db.transaction(
            function(tx) {

                var l = sapatos.length;
                var sql =
                     "INSERT OR REPLACE INTO SAPATO (id, code, brand_id, brand_name, line_id, price, costo, reference_id, material_id, color_id, photo, linha_desc, referencia_id, color_code, color_desc, material_desc, lastModified, linha, grid) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                console.log('Inserindo ou atualizando dados no SQLite local');
                var i;
                for (var i = 0; i < l; i++) {
                    e = sapatos[i];

                    var grid = [];

                    for (var o = 0; o < e.grids_and_sizes.length; o++) {
                        grid.push({grid_desc: e.grids_and_sizes[o].description, grid_id: e.grids_and_sizes[o].id})
                    }

                    var params = [e.id, e.code, e.brand_id, e.brand.name, e.line_id, e.price, e.cost, e.reference_id, e.material_id, e.color_id, e.photo, e.line.description, e.line_id, e.color.color, e.color.description, e.material.description, e.updated_at, e.line.code, JSON.stringify(grid)];                    
                    tx.executeSql(sql, params);
                }
                console.log('Sincronização completa (' + l + ' items sincronizados)');
            },
            this.txErrorHandler,
            function(tx) {
                callback();
            }
        );
    },

    syncFilters: function(){
        this.db.transaction(
            function(tx) {
                $('#select-linha').empty();
                $('#select-linha').append($('<option>', {
                    value: '*',
                    text: 'Todas las lineas'
                }));
                $('#select-cores').empty();
                $('#select-cores').append($('<option>', {
                    value: '*',
                    text: 'Todas las cores'
                }));
                $('#select-material').empty();
                $('#select-material').append($('<option>', {
                    value: '*',
                    text: 'Todos los materiales'
                }));
                var coresSQL        =   "SELECT MIN(color_desc) AS cores FROM sapato WHERE brand_id = '"+brands.selecionada+"' GROUP by color_desc";
                var linhasSQL       =   "SELECT MIN(linha_desc) AS linha FROM sapato WHERE brand_id = '"+brands.selecionada+"' GROUP by linha_desc";
                var materiaisSQL    =   "SELECT MIN(material_desc) AS materiais FROM sapato WHERE brand_id = '"+brands.selecionada+"' GROUP by material_desc";
                tx.executeSql(coresSQL, this.txErrorHandler,
                    function(tx, results) {
                        var len = results.rows.length,
                            cores = [],
                            i = 0;
                        for (; i < len; i = i + 1) {
                            cores[i] = results.rows.item(i);
                            $('#select-cores').append($('<option>', {
                                value: '.cor'+decodeURI(cores[i].cores),
                                text: cores[i].cores
                            }));
                        }
                    }
                );
                tx.executeSql(linhasSQL, this.txErrorHandler,
                    function(tx2, linhaRes) {
                        var len = linhaRes.rows.length,
                            linhas = [],
                            i = 0;
                        for (; i < len; i = i + 1) {
                            linhas[i] = linhaRes.rows.item(i);
                            $('#select-linha').append($('<option>', {
                                value: '.linea'+linhas[i].linha,
                                text: linhas[i].linha
                            }));
                        }
                    }
                );
                tx.executeSql(materiaisSQL, this.txErrorHandler,
                    function(tx3, materiaisList) {
                        var len = materiaisList.rows.length,
                            materiais = [],
                            i = 0;
                        for (; i < len; i = i + 1) {
                            materiais[i] = materiaisList.rows.item(i);
                            $('#select-material').append($('<option>', {
                                value: '.material'+materiais[i].materiais.split(' ').join('_'),
                                text: materiais[i].materiais
                            }));
                        }
                    }
                );
            }
        );

    },

    listGrid: function(id_grid){
        this.db.transaction(
            function(tx) {
                var gridSQL =   "SELECT grid FROM sapato WHERE id =" + id_grid;
                tx.executeSql(gridSQL, this.txErrorHandler,
                    function(tx, results) {
                        var resultadosArray = JSON.parse(results.rows.item(tx).grid);
                        
                        $('#recebeGrid').append($('<option>', {
                            value: '*',
                            text: 'Todas las lineas'
                        }));
                
                        $.each(resultadosArray, function(i, item) {
                            $('.recebeGrid').append($('<option>', {
                                value: item.grid_id,
                                text: item.grid_desc
                            }));

                        });


                    }   
                );
            }
        );

    },

    txErrorHandler: function(tx) {
        console.log(tx.message);
    }
};

catalogo.initialize(function() {
    console.log('SQLite iniciado');
});


function renderList(sapatos) {
    var $grid = $('#sapatosList');

    catalogo.findAll(function(sapatos) {
        $('#sapatosList').empty();
        var l = sapatos.length;
        for (var i = 0; i < l; i++) {
            var sapato = sapatos[i];
            $('#sapatosList').append('<div class="sapatoItem cor'+sapato.color_desc.split(' ').join('_')+' linea'+sapato.linha_desc+' material'+sapato.material_desc.split(' ').join('_')+'" >' +
                '<a href="#" data-rel="popup" id="'+[i]+'" data-transition="pop" data-position-to="origin" data-grid="'+sapato.grid+'" data-photo="'+sapato.photo+'" class="innerSapatoItem" productID="'+sapato.id+'" data-brand="'+sapato.brand_name+'" data-color="'+sapato.color_desc+'" data-hex="'+sapato.color_code+'" data-preco="'+sapato.price+'" data-costo="'+sapato.costo+'" data-material="'+sapato.material_id+'" data-code="'+sapato.code+'"  data-strColor="'+sapato.color_desc+'" data-strGrid="2" data-strLine="'+sapato.linha_desc+'" data-strMaterial="'+sapato.material_desc+'" data-grid_id="0"> ' +
                '<section>' +
                '<div class="sapatoImage">' +
                '<img src="'+sapato.photo+'" class="cached-img">' +
                '</div>' +
                '<h1>'+sapato.linha_desc+' '+sapato.material_desc+'</h1>' +
                '<span>'+sapato.color_desc+'</span>' +
                '</section>' +
                '</a>' +
                '</div>'
            );
        }
        window.localStorage.setItem('everSynced','true');
        // Cria a modal com o conteúdo dos sapatos
        $( ".innerSapatoItem" ).on( "click", function() {
            var target          = $( this ),
                price           = target.attr("data-preco");
                costo           = target.attr('data-costo');
                color           = target.attr('data-color');
                productid       = target.attr('productID');
                code            = target.attr('data-code');
                material        = target.attr('data-material');
                colorhex        = target.attr('data-hex');
                photo           = target.attr('data-photo');
                img             = target.find( "img" ).attr('src');
                short           = target.attr( "id" );
                brand           = target.attr('data-brand');
                strMaterial     = target.attr('data-strMaterial');
                strColor        = target.attr('data-strColor');
                strLine         = target.attr('data-strLine');
                closebtn        = '<a href="#" data-rel="back" class="ui-btn ui-corner-all ui-btn-a ui-icon-delete ui-btn-icon-notext ui-btn-right">Close</a>';

                popup = '<div data-role="popup" data-tolerance="15,15" id="popup-' + short + '" data-short="' + short +'" class="recebeDadosSapato">' + 
                '<div data-role="main">' +
                '<figure><img src="'+img+'" class="cached-img" /></figure>' +
                '<h4 style="width:100%; text-align:center">'+strLine+' '+strMaterial+' '+strColor+'</h4>'+
                '<ul class="dadosSapato">' +
                '<li>Preço</li>' +
                '<li>AR$ <b>'+ price +'</b></li>' +
                '<li>Quantidade</li>' +
                '<li><input type="number" min="0" max="100" name="recebeQtd" class="recebeQtd" value="1"></li>' +
                '<li>Grade</li>' +
                '<li class="tarea"><select name="recebeGrid" class="recebeGrid" data-mini="true" data-inline="true"><option value="1">Tarea A</option><option value="2">Tarea B</option><option value="3">Tarea D</option><option value="4">Tarea H</option></select> </li>' +
                '<li>Desconto de Representante</li>' +
                '<li> <input type="number" min="0" max="100" name="descontoRepresentante" class="descontoRepresentante" placeholder="Digite um valor"> </li>' +
                '<li>Desconto de Cliente</li>' +
                '<li> <input type="number" min="0" max="100" name="descontoCliente" class="descontoCliente" placeholder="Digite um valor"> </li>' +
                '</ul>' +
                '<a href="#" class="addPedido"  data-costo="'+costo+'" productid="'+productid+'" data-photo="'+photo+'" data-price="'+price+'"  data-code="'+code+'" data-material="'+material+'" data-strColor="'+strColor+'" data-strLine="'+strLine+'" data-strMaterial="'+strMaterial+'" data-strGrid="0" data-grid_id="0">ADICIONAR AO PEDIDO</a>'
                '</div>';
            
                $.mobile.activePage.append( popup ).trigger( "pagecreate" );

                $( ".photo", "#popup-" + short ).load(function() {
                    var height = $( this ).height(),
                        width = $( this ).width();

                    $( this ).attr({ "height": height, "width": width });

                    $( "#popup-" + short ).popup( "open" );

                    clearTimeout( fallback );
                });

                var fallback = setTimeout(function() {
                    $( "#popup-" + short ).popup( "open" );
                }, 100);

        });

        $( document ).on( "popupbeforeposition", ".ui-popup", function() {
            var maxHeight = $( window ).height() - 68 + "px";
            $( "img.photo", this ).css( "max-height", maxHeight );
            $(this).css('z-index','9999');
            $('body').css('overflow', 'hidden').on('touchmove', function(e) {
                 e.preventDefault();
            });
        });

        $( document ).on( "popupafterclose", ".ui-popup", function() {
            $( this ).remove();
            $('body').css('overflow', 'auto').off('touchmove');
        });

        // $('#sapatosList').css('opacity','0');

        $.mobile.loading('show', {text: "Carregando Catálogo", textVisible: "Carregando Catálogo"});

        //  var obj = $('#sapatosList div');

        // $.each( obj, function( key, value ) {
        //   var target = $(this).find('img');

        //   ImgCache.cacheFile(target.attr('src'), function () {
        //       ImgCache.useCachedFile(target, function () {
        //         console.log('SAPATOS - now using local copy');
        //       }, function(){
        //        consoe.log('SAPATOS - could not load from cache');
        //       })
        //     });
        // });

        $grid.imagesLoaded()
          .always( function( instance ) {
          })
          .done( function( instance ) {

            $grid.isotope('destroy');

            $grid.isotope({
                itemSelector: '.sapatoItem',
                transitionDuration: 0
            });

             $.mobile.loading('hide');


          })
          .fail( function() {


            $grid.isotope('destroy');

            $.mobile.loading('hide');
            $grid.isotope({
                itemSelector: '.sapatoItem',
                transitionDuration: 0
            });
            // $('#sapatosList').css('opacity','1');
          })
          .progress( function( instance, image ) { });

        $('.filters-select').on( 'change', function() {
          var filterValue = this.value;
          filterValue = filterValue;
          $grid.isotope({ filter: filterValue.split(' ').join('_') });
        });



    });
}


// $(function() {
//     $( "[data-role='navbar']" ).navbar();
//     $( "[data-role='header'], [data-role='footer']" ).toolbar();
// });
// // Update the contents of the toolbars
// $( document ).on( "pagecontainerchange", function() {
//     // Each of the four pages in this demo has a data-title attribute
//     // which value is equal to the text of the nav button
//     // For example, on first page: <div data-role="page" data-title="Info">
//     var current = $( ".ui-page-active" ).jqmData( "title" );
//     // Change the heading
//     $( "[data-role='header'] h1" ).text( current );
//     // Remove active class from nav buttons
//     $( "[data-role='navbar'] a.ui-btn-active" ).removeClass( "ui-btn-active" );
//     // Add active class to current nav button
//     $( "[data-role='navbar'] a" ).each(function() {
//         if ( $( this ).text() === current ) {
//             $( this ).addClass( "ui-btn-active" );
//         }
//     });
// });


